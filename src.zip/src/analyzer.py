from collections import Counter
import re

def analyze_words(headers):
    words = []
    for header in headers:
        clean_words = re.findall(r'\b\w+\b', header.lower())
        words.extend(clean_words)

    counter = Counter(words)
    return {word: count for word, count in counter.items() if count > 2}
