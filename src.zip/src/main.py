import time
import requests

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

from translator import translate_text
from analyzer import analyze_words


#SETUP DRIVER
options = Options()
options.add_argument("--start-maximized")

service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)

wait = WebDriverWait(driver, 15)


# OPEN EL PAÍS
driver.get("https://elpais.com/")
time.sleep(5)


# HANDLE COOKIE POPUP
try:
    accept_btn = wait.until(
        EC.element_to_be_clickable(
            (By.XPATH, "//button[contains(text(),'Aceptar')]")
        )
    )
    accept_btn.click()
except:
    pass  # Cookie popup may not appear


#GO TO OPINIÓN 
wait.until(
    EC.element_to_be_clickable((By.LINK_TEXT, "Opinión"))
).click()

time.sleep(5)


#GET FIRST 5 ARTICLE LINKS
article_links = driver.find_elements(
    By.CSS_SELECTOR, "article a[href]"
)[:5]

main_window = driver.current_window_handle
translated_headers = []


#PROCESS EACH ARTICLE 
for index, article in enumerate(article_links, start=1):
    try:
        link = article.get_attribute("href")

        # Open article in new tab
        driver.execute_script("window.open(arguments[0]);", link)
        driver.switch_to.window(driver.window_handles[-1])

        # Wait for article title
        title_element = wait.until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "h1"))
        )

        title = title_element.text

        print(f"\nArticle {index}")
        print("Title (Spanish):", title)

        # Translate title
        translated = translate_text(title)
        translated_headers.append(translated)
        print("Title (English):", translated)

        # Download image if available
        try:
            img = driver.find_element(By.TAG_NAME, "img")
            img_url = img.get_attribute("src")
            img_data = requests.get(img_url).content

            with open(f"images/article_{index}.jpg", "wb") as f:
                f.write(img_data)

            print("Image saved")
        except:
            print("No image found")

        # Close article tab
        driver.close()
        driver.switch_to.window(main_window)

    except Exception as e:
        print("Skipping article due to error:", e)
        driver.switch_to.window(main_window)


# ANALYZE REPEATED WORDS
driver.quit()

repeated_words = analyze_words(translated_headers)

print("\nRepeated Words:")
for word, count in repeated_words.items():
    print(word, "->", count)


# FINAL SUMMARY OUTPUT 
print("\n" + "=" * 60)
print("SCRAPING & TRANSLATION SUMMARY")
print("=" * 60)
print("Website       : https://elpais.com/")
print("Section       : Opinión")
print(f"Articles Read : {len(translated_headers)}")

print("\nTranslated Headlines:")
for i, title in enumerate(translated_headers, start=1):
    print(f"{i}. {title}")

print("\n✔ Each article opened individually")
print("✔ Spanish headlines extracted")
print("✔ Headlines translated to English")
print("✔ Articles closed safely")
print("=" * 60)
